import { Layout } from "@/components/Layout";
import { EditableText } from "@/components/EditableText";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { BookOpen, HelpCircle, ShieldAlert, Crosshair, Youtube, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Learn() {
  return (
    <Layout>
      <div className="bg-secondary/20 py-12 border-b border-white/5">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">Learn Chess</h1>
          <p className="text-muted-foreground max-w-2xl">
            From beginner basics to advanced strategies, start your journey here.
          </p>
        </div>
      </div>

      <div className="container py-12 space-y-12">
        {/* Video Resources Section */}
        <section className="space-y-6">
          <h2 className="text-2xl font-display font-bold text-white border-l-4 border-primary pl-4">Video Resources</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="bg-card border-white/10 overflow-hidden group hover:border-primary/50 transition-all">
                <div className="aspect-video bg-secondary/30 flex items-center justify-center relative">
                  <Youtube className="h-12 w-12 text-red-600 opacity-80 group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                </div>
                <CardContent className="p-4 space-y-3">
                  <EditableText 
                    id={`learn.video.${i}.title`} 
                    className="font-bold text-white block" 
                    defaultText={i === 1 ? "Chess Openings for Beginners" : i === 2 ? "Mastering the Endgame" : "Tactics & Combinations"}
                  />
                  <Button variant="outline" size="sm" className="w-full gap-2 border-primary/30 hover:bg-primary/10 text-primary" asChild>
                    <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
                      <PlayCircle size={14} /> Watch on YouTube
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="grid gap-8 md:grid-cols-2">
          {/* How Pieces Move */}
          <Card className="bg-card border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <BookOpen className="h-5 w-5" />
                <EditableText id="learn.moves.title" defaultText="How Pieces Move" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <EditableText 
                id="learn.moves.text" 
                as="div" 
                multiline 
                className="text-muted-foreground leading-relaxed"
                defaultText="The King moves one square in any direction. The Queen moves any number of squares diagonally, horizontally, or vertically. The Rook moves horizontally or vertically. The Bishop moves diagonally. The Knight moves in an L-shape. The Pawn moves forward, but captures diagonally." 
              />
            </CardContent>
          </Card>

          {/* Basic Checkmate Patterns */}
          <Card className="bg-card border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Crosshair className="h-5 w-5" />
                <EditableText id="learn.checkmates.title" defaultText="Basic Checkmates" />
              </CardTitle>
            </CardHeader>
            <CardContent>
               <EditableText 
                id="learn.checkmates.text" 
                as="div" 
                multiline 
                className="text-muted-foreground leading-relaxed"
                defaultText="1. King & Queen vs King: Force the enemy king to the edge of the board. 2. King & Rook vs King: Use your king to cut off escape squares. 3. Back Rank Mate: Checkmate on the back rank when pawns block escape." 
              />
            </CardContent>
          </Card>

          {/* Opening Principles */}
          <Card className="bg-card border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <HelpCircle className="h-5 w-5" />
                <EditableText id="learn.openings.title" defaultText="Opening Principles" />
              </CardTitle>
            </CardHeader>
            <CardContent>
               <EditableText 
                id="learn.openings.text" 
                as="div" 
                multiline 
                className="text-muted-foreground leading-relaxed"
                defaultText="1. Control the Center: e4/d4 are best. 2. Develop Pieces: Knights before Bishops. 3. King Safety: Castle early! 4. Don't move the same piece twice in the opening unless necessary." 
              />
            </CardContent>
          </Card>

          {/* Common Mistakes */}
          <Card className="bg-card border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-500">
                <ShieldAlert className="h-5 w-5" />
                <EditableText id="learn.mistakes.title" defaultText="Common Beginner Mistakes" />
              </CardTitle>
            </CardHeader>
            <CardContent>
               <EditableText 
                id="learn.mistakes.text" 
                as="div" 
                multiline 
                className="text-muted-foreground leading-relaxed"
                defaultText="1. Playing too fast. 2. Leaving pieces undefended (Hanging pieces). 3. Not looking at your opponent's threats. 4. Bringing the Queen out too early. 5. Focusing only on your own plan." 
              />
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
}
