import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Send, CheckCircle2, Loader2, AlertCircle, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isError, setIsError] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });

  const validateEmail = (email: string) => {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsError(false);

    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        variant: "destructive",
        title: "Validation Failed",
        description: "All fields are required for professional inquiry.",
      });
      return;
    }

    if (!validateEmail(formData.email)) {
      toast({
        variant: "destructive",
        title: "Invalid Email",
        description: "Please provide a valid business email address.",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulated async submission
      await new Promise((resolve, reject) => {
        setTimeout(() => {
          // Simulate 5% chance of failure for UI testing
          if (Math.random() < 0.05) reject(new Error("Simulated failure"));
          else resolve(true);
        }, 2500);
      });

      setIsSuccess(true);
      toast({
        title: "Submission Successful",
        description: "Your inquiry has been logged in our secure registry.",
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
    } catch (error) {
      setIsError(true);
      toast({
        variant: "destructive",
        title: "System Error",
        description: "Submission failed. Please contact us directly at info@mychesshub.com",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="bg-secondary/10 py-24 border-b border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/20 blur-[120px] rounded-full animate-pulse" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/10 blur-[100px] rounded-full" />
        </div>
        <div className="container relative z-10 text-center space-y-4">
          <h1 className="text-6xl md:text-8xl font-display font-black text-white mb-6 tracking-tight uppercase animate-in fade-in slide-in-from-top-12 duration-1000">
            Contact <span className="text-primary">HQ</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-light leading-relaxed animate-in fade-in duration-1000 delay-300 uppercase tracking-[0.2em] opacity-80">
            Professional inquiries and tournament registration support.
          </p>
        </div>
      </div>

      <div className="container py-24 min-h-[70vh] flex items-center justify-center">
        <div className="w-full max-w-2xl relative">
          {isSuccess ? (
            <div className="glass-card p-20 text-center animate-in zoom-in duration-700 border-primary/30 shadow-[0_0_50px_rgba(16,185,129,0.15)] relative overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-1 bg-primary shadow-[0_0_20px_rgba(16,185,129,0.8)]" />
               <div className="bg-primary/10 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-10 border border-primary/20 animate-in scale-in duration-500 delay-200">
                 <CheckCircle2 className="h-12 w-12 text-primary" />
               </div>
               <h2 className="text-4xl font-display font-black text-white mb-6 uppercase tracking-tight">Transmission Received</h2>
               <p className="text-muted-foreground text-lg mb-12 uppercase tracking-widest text-sm leading-relaxed opacity-70">Your message has been encrypted and sent to our administrative team. Expected response time: 24 Hours.</p>
               <Button 
                onClick={() => setIsSuccess(false)}
                className="bg-primary text-primary-foreground font-black px-12 py-8 uppercase tracking-[0.3em] rounded-none text-xs hover:shadow-[0_0_30px_rgba(16,185,129,0.4)] transition-all active:scale-95 h-auto"
               >
                 New Submission
               </Button>
            </div>
          ) : (
            <div className="glass-card p-12 relative animate-in fade-in slide-in-from-bottom-12 duration-1000 border-white/10 shadow-2xl">
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-secondary border border-white/10 px-6 py-2 flex items-center gap-3">
                <ShieldCheck size={14} className="text-primary" />
                <span className="text-[10px] font-black text-white uppercase tracking-[0.4em]">Secure Terminal</span>
              </div>

              <form className="space-y-10" onSubmit={handleSubmit}>
                <div className="grid gap-10 sm:grid-cols-2">
                  <div className="space-y-3 group">
                    <label className="text-[10px] font-black text-primary/60 tracking-[0.3em] uppercase group-focus-within:text-primary transition-colors">Full Name</label>
                    <Input 
                      placeholder="e.g. Magnus Carlsen" 
                      className="bg-black/60 border-white/10 rounded-none h-16 focus:border-primary focus:ring-1 focus:ring-primary transition-all text-white text-sm font-bold uppercase tracking-widest px-6 placeholder:text-white/10"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="space-y-3 group">
                    <label className="text-[10px] font-black text-primary/60 tracking-[0.3em] uppercase group-focus-within:text-primary transition-colors">Electronic Mail</label>
                    <Input 
                      type="email" 
                      placeholder="user@network.com" 
                      className="bg-black/60 border-white/10 rounded-none h-16 focus:border-primary focus:ring-1 focus:ring-primary transition-all text-white text-sm font-bold uppercase tracking-widest px-6 placeholder:text-white/10"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      disabled={isSubmitting}
                    />
                  </div>
                </div>

                <div className="space-y-3 group">
                  <label className="text-[10px] font-black text-primary/60 tracking-[0.3em] uppercase group-focus-within:text-primary transition-colors">Subject Header</label>
                  <Input 
                    placeholder="Inquiry Category" 
                    className="bg-black/60 border-white/10 rounded-none h-16 focus:border-primary focus:ring-1 focus:ring-primary transition-all text-white text-sm font-bold uppercase tracking-widest px-6 placeholder:text-white/10"
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                    disabled={isSubmitting}
                  />
                </div>

                <div className="space-y-3 group">
                  <label className="text-[10px] font-black text-primary/60 tracking-[0.3em] uppercase group-focus-within:text-primary transition-colors">Detailed Message</label>
                  <Textarea 
                    placeholder="Provide transmission details..." 
                    className="min-h-[200px] bg-black/60 border-white/10 rounded-none focus:border-primary focus:ring-1 focus:ring-primary transition-all text-white text-sm font-bold uppercase tracking-widest px-6 pt-6 placeholder:text-white/10 leading-relaxed resize-none"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    disabled={isSubmitting}
                  />
                </div>

                {isError && (
                  <div className="bg-red-500/10 border border-red-500/30 p-4 flex items-center gap-4 animate-in slide-in-from-top-2">
                    <AlertCircle size={18} className="text-red-500" />
                    <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">Network transmission failed. Please try again.</span>
                  </div>
                )}

                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-[#10B981] to-[#059669] hover:from-[#34D399] hover:to-[#10B981] text-primary-foreground font-black py-10 rounded-none transition-all duration-500 relative overflow-hidden group uppercase tracking-[0.4em] text-xs h-auto shadow-[0_15px_30px_-10px_rgba(16,185,129,0.4)] active:scale-[0.98] disabled:opacity-50 disabled:grayscale"
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-4">
                      <Loader2 className="h-6 w-6 animate-spin" /> 
                      Encrypting...
                    </div>
                  ) : (
                    <div className="flex items-center gap-4">
                      <Send className="h-5 w-5 group-hover:translate-x-2 group-hover:-translate-y-2 transition-transform duration-500" />
                      Initiate Transmission
                    </div>
                  )}
                  <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>
              </form>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
