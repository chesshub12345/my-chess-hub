import { Layout } from "@/components/Layout";
import { EditableText } from "@/components/EditableText";
import { ResultsTable } from "@/components/ResultsTable";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import heroBg from "@/assets/hero-bg.png";
import { useContent } from "@/lib/ContentContext";
import { Trophy, Users, Globe, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Home() {
  const { tournaments } = useContent();
  const [searchQuery, setSearchQuery] = useState("");
  
  const activeTournaments = tournaments.filter(t => t.status !== 'Completed').length;
  const totalPlayers = tournaments.length * 40; // Mock stat

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative h-[85vh] min-h-[600px] flex items-center justify-center overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroBg} 
            alt="Chess Hero" 
            className="w-full h-full object-cover grayscale opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>

        <div className="container relative z-10 text-center space-y-10 animate-in fade-in zoom-in duration-700">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold tracking-widest uppercase mb-4">
            <Trophy size={14} /> Official Malaysia Chess Hub
          </div>
          
          <EditableText 
            id="home.hero.title" 
            as="h1" 
            defaultText="MY CHESS HUB" 
            className="text-7xl md:text-9xl font-display font-black text-white tracking-tighter leading-none"
          />
          <EditableText 
            id="home.hero.subtitle" 
            as="p" 
            defaultText="Tournaments • Results • Learning" 
            className="text-xl md:text-2xl text-muted-foreground font-medium tracking-[0.3em] uppercase max-w-3xl mx-auto"
          />
          
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-6">
            <Link href="/tournaments">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-12 py-8 text-xl rounded-none transition-all btn-hover-glow uppercase tracking-widest">
                Explore Events
              </Button>
            </Link>
            <Link href="/tournaments">
              <Button variant="outline" size="lg" className="font-bold px-10 py-8 text-xl rounded-none border-white/20 hover:bg-white/5 transition-all text-white uppercase tracking-widest">
                Create Tournament
              </Button>
            </Link>
          </div>

          {/* Search Bar Preview */}
          <div className="max-w-xl mx-auto mt-12 relative group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
            </div>
            <Input 
              placeholder="Search tournaments, states, or players..." 
              className="h-14 pl-12 bg-white/5 border-white/10 rounded-none text-lg focus:border-primary transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
               <div className="absolute top-full left-0 right-0 bg-secondary border border-white/10 mt-2 z-50 p-4 text-left animate-in slide-in-from-top-2">
                 <p className="text-sm text-muted-foreground">Searching for "{searchQuery}"...</p>
                 <Link href={`/tournaments?search=${searchQuery}`}>
                   <Button variant="link" className="text-primary p-0 h-auto mt-2">View all results &rarr;</Button>
                 </Link>
               </div>
            )}
          </div>
        </div>
      </section>

      {/* Stats Counter Section */}
      <section className="py-12 border-b border-white/5 bg-secondary/20">
        <div className="container grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center space-y-2">
            <div className="text-4xl font-display font-black text-primary">{activeTournaments}</div>
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Live Tournaments</div>
          </div>
          <div className="text-center space-y-2">
            <div className="text-4xl font-display font-black text-white">{totalPlayers}+</div>
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Active Players</div>
          </div>
          <div className="text-center space-y-2">
            <div className="text-4xl font-display font-black text-white">16</div>
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">States Covered</div>
          </div>
          <div className="text-center space-y-2">
            <div className="text-4xl font-display font-black text-white">24/7</div>
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Support Access</div>
          </div>
        </div>
      </section>

      {/* Quick Navigation Buttons */}
      <section className="py-12 border-b border-white/5">
        <div className="container flex flex-wrap justify-center gap-4">
           <Link href="/tournaments?tab=malaysia">
              <Button variant="outline" className="rounded-none border-white/10 hover:border-primary transition-colors px-8 py-6 h-auto font-bold uppercase tracking-wider flex items-center gap-2">
                <Globe size={18} className="text-primary" /> Malaysian Circuit
              </Button>
           </Link>
           <Link href="/tournaments?tab=international">
              <Button variant="outline" className="rounded-none border-white/10 hover:border-primary transition-colors px-8 py-6 h-auto font-bold uppercase tracking-wider flex items-center gap-2">
                <Globe size={18} className="text-primary" /> World Tournaments
              </Button>
           </Link>
           <Link href="/learn">
              <Button variant="outline" className="rounded-none border-white/10 hover:border-primary transition-colors px-8 py-6 h-auto font-bold uppercase tracking-wider flex items-center gap-2">
                <Users size={18} className="text-primary" /> Learning Hub
              </Button>
           </Link>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-24 bg-background">
        <div className="container max-w-3xl text-center space-y-10">
          <h2 className="text-sm font-display font-bold text-primary tracking-[0.3em] uppercase">Who We Are</h2>
          <EditableText 
            id="home.intro.text" 
            as="p" 
            multiline
            defaultText="MY Chess Hub is a platform dedicated to sharing updated chess tournament information, results, and learning resources, covering Malaysia and the international chess scene." 
            className="text-2xl text-white font-light leading-relaxed italic"
          />
        </div>
      </section>

      {/* Latest Results Section */}
      <section className="py-20 bg-secondary/10 border-y border-white/5">
        <div className="container max-w-5xl">
          <div className="text-center mb-12">
            <EditableText 
              id="home.latest.title" 
              as="h2" 
              defaultText="Latest Results" 
              className="text-3xl md:text-4xl font-display font-bold text-white mb-4 inline-block border-b-2 border-primary pb-2"
            />
          </div>
          
          <ResultsTable limit={5} title="Recent Champions" showCountry={true} />
          
          <div className="mt-8 text-center">
             <Link href="/tournaments">
              <Button variant="link" className="text-primary hover:text-primary/80">
                View All Results &rarr;
              </Button>
             </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
