import { Layout } from "@/components/Layout";
import { EditableText } from "@/components/EditableText";
import { ResultsTable } from "@/components/ResultsTable";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { useContent } from "@/lib/ContentContext";
import { Button } from "@/components/ui/button";
import { Trash2, MapPin, Calendar, Trophy, Info, Loader2, Filter, Plus } from "lucide-react";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

export default function Tournaments() {
  const [isLoading, setIsLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [formatFilter, setFormatFilter] = useState("All");
  const { tournaments, isEditing } = useContent();

  useEffect(() => {
    // Simulated async data fetch
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, [categoryFilter, formatFilter]);

  const filteredTournaments = tournaments.filter(t => {
    const matchesCategory = categoryFilter === "All" || 
      (categoryFilter === "Domestic" ? (t.country === 'Malaysia' || !t.country) : t.country !== 'Malaysia');
    const matchesFormat = formatFilter === "All" || t.category.toLowerCase().includes(formatFilter.toLowerCase());
    return matchesCategory && matchesFormat && t.status !== 'Completed';
  });

  return (
    <Layout>
      <div className="bg-secondary/10 py-24 border-b border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(circle_at_50%_50%,#10B981,transparent_70%)]" />
        <div className="container relative z-10 text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-display font-black text-white tracking-tight uppercase animate-in fade-in slide-in-from-top-8 duration-700">
            Premium <span className="text-primary">Tournaments</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto font-light leading-relaxed animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200 uppercase tracking-widest">
            The professional circuit for elite chess players.
          </p>
        </div>
      </div>

      <div className="container py-12">
        {isEditing && (
          <div className="mb-8 flex justify-end">
            <Link href="/tournaments/create">
              <Button className="bg-primary text-primary-foreground gap-2 uppercase text-[10px] font-black tracking-widest px-8 py-6 h-auto rounded-none shadow-[0_10px_20px_rgba(16,185,129,0.2)]">
                <Plus size={16} /> Create New Tournament
              </Button>
            </Link>
          </div>
        )}
        {/* Advanced Filters */}
        <div className="glass-card p-8 mb-16 flex flex-col lg:flex-row items-center justify-center gap-12 animate-in fade-in duration-1000 border border-white/10 shadow-2xl">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="flex items-center gap-3 text-primary">
              <Filter size={14} className="animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-[0.3em]">Category</span>
            </div>
            <div className="flex bg-black/40 p-1 border border-white/10 rounded-sm">
              {["All", "Domestic", "International"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={cn(
                    "px-6 py-2 text-[10px] font-bold uppercase tracking-widest transition-all duration-300 rounded-sm",
                    categoryFilter === cat 
                      ? "bg-primary text-primary-foreground shadow-[0_0_20px_rgba(16,185,129,0.4)]" 
                      : "text-muted-foreground hover:text-white"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="flex items-center gap-3 text-primary">
              <Trophy size={14} className="animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-[0.3em]">Format</span>
            </div>
            <div className="flex bg-black/40 p-1 border border-white/10 rounded-sm">
              {["All", "Classical", "Rapid", "Blitz"].map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => setFormatFilter(fmt)}
                  className={cn(
                    "px-6 py-2 text-[10px] font-bold uppercase tracking-widest transition-all duration-300 rounded-sm",
                    formatFilter === fmt 
                      ? "bg-primary text-primary-foreground shadow-[0_0_20px_rgba(16,185,129,0.4)]" 
                      : "text-muted-foreground hover:text-white"
                  )}
                >
                  {fmt}
                </button>
              ))}
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="py-40 flex flex-col items-center justify-center space-y-8 animate-in fade-in duration-500">
            <div className="relative">
              <Loader2 className="h-16 w-16 text-primary animate-spin" />
              <div className="absolute inset-0 bg-primary/20 blur-xl animate-pulse rounded-full" />
            </div>
            <p className="text-[10px] font-black uppercase tracking-[0.5em] text-primary animate-pulse">Synchronizing Data...</p>
          </div>
        ) : (
          <div className="animate-in fade-in duration-700">
            <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3 mb-32">
              {filteredTournaments.length === 0 ? (
                <div className="col-span-full py-32 text-center glass-card border-dashed border-white/10 animate-in zoom-in duration-500">
                  <Trophy className="mx-auto h-20 w-16 text-muted-foreground/10 mb-8" />
                  <h3 className="text-3xl font-display font-bold text-white uppercase mb-4 tracking-tight">No Events Found</h3>
                  <p className="text-muted-foreground uppercase text-[10px] font-bold tracking-[0.2em] mb-10 max-w-sm mx-auto opacity-60">We couldn't find any tournaments matching your current filter selection.</p>
                  <Button 
                    variant="outline" 
                    className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground uppercase text-[10px] font-black tracking-[0.2em] px-10 py-6 rounded-none h-auto transition-all"
                    onClick={() => {setCategoryFilter("All"); setFormatFilter("All");}}
                  >
                    Clear Filter Registry
                  </Button>
                </div>
              ) : (
                filteredTournaments.map((t, idx) => (
                  <Card 
                    key={t.id} 
                    className="group relative rounded-none bg-white/[0.03] backdrop-blur-xl border-white/10 hover:border-primary/50 transition-all duration-500 hover:-translate-y-3 hover:scale-[1.03] hover:shadow-[0_30px_60px_-12px_rgba(16,185,129,0.25)] overflow-hidden animate-in fade-in slide-in-from-bottom-12"
                    style={{ animationDelay: `${idx * 150}ms` }}
                  >
                    {/* Status Badge */}
                    <div className="absolute top-0 right-0 p-6 z-10">
                       <Badge className="rounded-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] bg-primary text-primary-foreground border-none shadow-[0_0_20px_rgba(16,185,129,0.5)]">
                         {t.status}
                       </Badge>
                    </div>

                    <CardHeader className="p-10 pb-6 relative">
                      <div className="text-[10px] font-black text-primary/80 uppercase tracking-[0.4em] mb-6 flex items-center gap-3">
                        <span className="w-8 h-px bg-primary/30" />
                        {t.country || "MALAYSIA"}
                      </div>
                      <CardTitle className="text-3xl font-display font-black text-white leading-tight uppercase group-hover:text-primary transition-colors duration-500 tracking-tight">
                        {t.name}
                      </CardTitle>
                    </CardHeader>

                    <CardContent className="px-10 py-8 space-y-6 border-y border-white/5 bg-white/[0.02]">
                      <div className="flex items-center gap-5 group/item">
                        <div className="bg-primary/5 p-3 border border-white/5 group-hover/item:border-primary/30 transition-colors">
                          <MapPin size={18} className="text-primary/70 group-hover/item:text-primary transition-colors" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black text-primary/40 uppercase tracking-widest mb-1">Venue</span>
                          <span className="text-white font-bold uppercase tracking-tighter text-xs group-hover/item:text-white transition-colors">{t.location}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-5 group/item">
                        <div className="bg-primary/5 p-3 border border-white/5 group-hover/item:border-primary/30 transition-colors">
                          <Calendar size={18} className="text-primary/70 group-hover/item:text-primary transition-colors" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black text-primary/40 uppercase tracking-widest mb-1">Schedule</span>
                          <span className="text-white font-bold uppercase tracking-tighter text-xs group-hover/item:text-white transition-colors">{t.dates}</span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-6 pt-4 border-t border-white/5 mt-4">
                         <div className="space-y-1.5">
                            <span className="text-[8px] font-black text-primary uppercase tracking-[0.2em] block opacity-60">Format</span>
                            <span className="text-white font-black text-xs uppercase tracking-widest">{t.category.split(',')[0]}</span>
                         </div>
                         <div className="space-y-1.5 text-right">
                            <span className="text-[8px] font-black text-primary uppercase tracking-[0.2em] block opacity-60">Prize Fund</span>
                            <span className="text-white font-black text-xl tracking-tighter shadow-primary/20 drop-shadow-md">RM 5,000+</span>
                         </div>
                      </div>
                    </CardContent>

                    <CardFooter className="p-10">
                      <Button 
                        asChild 
                        className="w-full rounded-none bg-primary/5 hover:bg-primary text-primary hover:text-primary-foreground border border-primary/20 hover:border-primary transition-all duration-500 font-black tracking-[0.3em] py-8 text-[10px] uppercase group/btn relative overflow-hidden shadow-[inset_0_0_0_1px_rgba(16,185,129,0.1)] hover:shadow-[0_0_30px_rgba(16,185,129,0.3)]"
                        variant="outline"
                      >
                        <a href={t.link || "#"} target="_blank" rel="noopener noreferrer">
                          <span className="relative z-10 flex items-center justify-center">
                            View Details <Info size={14} className="ml-3 group-hover/btn:scale-110 transition-transform" />
                          </span>
                          <div className="absolute inset-0 bg-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                        </a>
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              )}
            </div>

            <section className="mb-32">
              <div className="flex items-center justify-between mb-16">
                <h2 className="text-4xl font-display font-black text-white border-l-[12px] border-primary pl-8 uppercase tracking-tighter leading-none">
                  Global <span className="text-primary">Hall of Fame</span>
                </h2>
              </div>
              <ResultsTable title="Circuit Results Archive" showCountry={true} />
            </section>

            <section>
              <div className="mb-16">
                <h2 className="text-4xl font-display font-black text-white border-l-[12px] border-primary pl-8 uppercase tracking-tighter leading-none">
                  Domestic <span className="text-primary">Registry</span>
                </h2>
                <p className="text-muted-foreground mt-6 ml-10 uppercase text-[10px] font-bold tracking-[0.4em] opacity-40">Official State Championship Repository.</p>
              </div>
              <StateChampionshipsList />
            </section>
          </div>
        )}
      </div>
    </Layout>
  );
}

function StateChampionshipsList() {
  const { stateChampionships, addStateChampionship, deleteStateChampionship, isEditing } = useContent();
  const states = [
    "Selangor", "Kuala Lumpur", "Johor", "Penang", "Perak", 
    "Negeri Sembilan", "Melaka", "Pahang", "Terengganu", 
    "Kelantan", "Kedah", "Perlis", "Sabah", "Sarawak", 
    "Putrajaya", "Labuan"
  ];

  const [newEntryState, setNewEntryState] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: "", date: "", categories: "", winner: "", link: "#" });

  const handleAdd = (state: string) => {
    addStateChampionship({ ...formData, state });
    setNewEntryState(null);
    setFormData({ name: "", date: "", categories: "", winner: "", link: "#" });
  };

  return (
    <Accordion type="single" collapsible className="w-full grid md:grid-cols-2 gap-8">
      {states.map((state) => {
        const stateData = stateChampionships.filter(s => s.state === state);
        
        return (
          <AccordionItem key={state} value={state} className="border border-white/5 rounded-none bg-white/[0.02] backdrop-blur-sm px-8 group data-[state=open]:bg-white/[0.05] data-[state=open]:border-primary/20 transition-all duration-500">
            <AccordionTrigger className="hover:no-underline py-10">
              <span className="text-2xl font-display font-black text-white uppercase tracking-tight group-data-[state=open]:text-primary transition-colors">{state}</span>
              <span className="text-[10px] font-black text-primary ml-auto mr-8 uppercase tracking-[0.2em] bg-primary/10 px-4 py-1.5 border border-primary/20 group-hover:shadow-[0_0_15px_rgba(16,185,129,0.2)] transition-all">
                {stateData.length} RECORDS
              </span>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-8 pt-2 pb-10">
                {stateData.length > 0 ? (
                  <div className="grid gap-6">
                    {stateData.map((item) => (
                      <Card key={item.id} className="bg-black/40 border-white/5 rounded-none group/item hover:border-primary/40 transition-all shadow-xl">
                        <CardHeader className="p-6 pb-0 flex flex-row items-center justify-between space-y-0 relative">
                          <div className="absolute top-0 left-0 w-1 h-full bg-primary/20 group-hover/item:bg-primary transition-colors" />
                          <CardTitle className="text-sm font-black text-primary uppercase tracking-[0.3em]">{item.name}</CardTitle>
                          {isEditing && (
                            <Button variant="ghost" size="icon" className="h-10 w-10 text-red-500 hover:bg-red-500/10" onClick={() => deleteStateChampionship(item.id)}>
                              <Trash2 size={16} />
                            </Button>
                          )}
                        </CardHeader>
                        <CardContent className="p-6 text-[10px] text-muted-foreground space-y-4 uppercase tracking-[0.2em]">
                          <div className="flex justify-between border-b border-white/5 pb-3">
                            <span className="text-white/20">Archived Date</span>
                            <span className="text-white font-bold">{item.date}</span>
                          </div>
                          <div className="flex justify-between border-b border-white/5 pb-3">
                            <span className="text-white/20">Grand Champion</span>
                            <span className="text-primary font-black text-xs">{item.winner}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/20">Classifications</span>
                            <span className="text-white font-bold">{item.categories}</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="py-16 text-center border border-dashed border-white/10 opacity-30">
                    <p className="text-[10px] font-black uppercase tracking-[0.5em] italic">Database Empty</p>
                  </div>
                )}

                {isEditing && (
                  <div className="pt-10 border-t border-white/5 mt-10">
                    {newEntryState === state ? (
                      <div className="space-y-6 bg-black/60 p-8 rounded-none text-xs border border-primary/40 animate-in zoom-in duration-300 shadow-[0_0_40px_rgba(16,185,129,0.1)]">
                        <div className="space-y-2">
                          <label className="text-[8px] font-black text-primary tracking-[0.4em] uppercase">Event Name</label>
                          <Input placeholder="Registry Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="h-12 text-[10px] bg-black/80 border-white/10 rounded-none text-white focus:border-primary focus:ring-1 focus:ring-primary" />
                        </div>
                        <div className="grid grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-[8px] font-black text-primary tracking-[0.4em] uppercase">Official Date</label>
                            <Input placeholder="MM/DD/YYYY" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="h-12 text-[10px] bg-black/80 border-white/10 rounded-none text-white focus:border-primary focus:ring-1 focus:ring-primary" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[8px] font-black text-primary tracking-[0.4em] uppercase">Champion</label>
                            <Input placeholder="Full Name" value={formData.winner} onChange={e => setFormData({...formData, winner: e.target.value})} className="h-12 text-[10px] bg-black/80 border-white/10 rounded-none text-white focus:border-primary focus:ring-1 focus:ring-primary" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[8px] font-black text-primary tracking-[0.4em] uppercase">Age Categories</label>
                          <Input placeholder="Classifications" value={formData.categories} onChange={e => setFormData({...formData, categories: e.target.value})} className="h-12 text-[10px] bg-black/80 border-white/10 rounded-none text-white focus:border-primary focus:ring-1 focus:ring-primary" />
                        </div>
                        <div className="flex gap-4 pt-6">
                          <Button size="lg" className="h-14 text-[10px] font-black uppercase tracking-widest w-full bg-primary text-primary-foreground rounded-none shadow-[0_0_25px_rgba(16,185,129,0.4)] hover:brightness-110 transition-all" onClick={() => handleAdd(state)}>Commit Entry</Button>
                          <Button size="lg" variant="ghost" className="h-14 text-[10px] font-black uppercase tracking-widest w-full rounded-none border border-white/5" onClick={() => setNewEntryState(null)}>Abort</Button>
                        </div>
                      </div>
                    ) : (
                      <Button variant="ghost" size="lg" className="w-full text-primary hover:text-primary-foreground hover:bg-primary h-16 text-[10px] font-black uppercase tracking-[0.4em] border border-dashed border-primary/30 transition-all duration-500 rounded-none shadow-sm" onClick={() => setNewEntryState(state)}>
                        <Plus size={20} className="mr-4" /> Append Archive Entry
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
}
