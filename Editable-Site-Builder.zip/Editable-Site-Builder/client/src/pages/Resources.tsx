import { Layout } from "@/components/Layout";
import { EditableText } from "@/components/EditableText";
import { Button } from "@/components/ui/button";
import { ExternalLink, Monitor, Book, Download } from "lucide-react";

export default function Resources() {
  return (
    <Layout>
      <div className="bg-secondary/20 py-12 border-b border-white/5">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">Resources</h1>
          <p className="text-muted-foreground max-w-2xl">
            Useful tools, websites, and downloads for chess improvement.
          </p>
        </div>
      </div>

      <div className="container py-12 space-y-16">
        {/* Online Platforms */}
        <section>
          <h2 className="text-2xl font-display font-bold text-white border-l-4 border-primary pl-4 mb-6 flex items-center gap-3">
            <Monitor className="text-primary" /> Online Platforms
          </h2>
          <div className="grid gap-6 md:grid-cols-3">
             {[
               { name: "Chess.com", url: "https://www.chess.com", desc: "The world's most popular chess website for playing and learning." },
               { name: "Lichess", url: "https://lichess.org", desc: "A free and open-source chess server for everyone." },
               { name: "Chess24", url: "https://www.chess.com/events", desc: "Follow major tournaments and enjoy world-class commentary." }
             ].map((platform, i) => (
               <div key={i} className="bg-card border border-white/10 p-6 rounded-none hover:border-primary/50 transition-colors flex flex-col">
                  <EditableText 
                    id={`resources.platform.${i + 1}.name`} 
                    className="text-xl font-bold text-white mb-2 block" 
                    defaultText={platform.name}
                  />
                  <EditableText 
                    id={`resources.platform.${i + 1}.desc`} 
                    className="text-sm text-muted-foreground mb-6 block min-h-[40px] flex-grow" 
                    defaultText={platform.desc}
                  />
                  <a 
                    href={platform.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center rounded-none bg-secondary hover:bg-primary hover:text-primary-foreground text-white border border-white/10 h-10 px-4 py-2 text-sm font-bold uppercase tracking-wider transition-all duration-300 ease-in-out hover:-translate-y-1 hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/30 cursor-pointer"
                  >
                    Visit Website <ExternalLink className="ml-2 h-3 w-3" />
                  </a>
               </div>
             ))}
          </div>
        </section>

        {/* Learning Tools */}
        <section>
          <h2 className="text-2xl font-display font-bold text-white border-l-4 border-primary pl-4 mb-6 flex items-center gap-3">
            <Book className="text-primary" /> Learning Tools
          </h2>
          <div className="bg-card border border-white/10 p-6 rounded-none">
            <ul className="grid gap-6 md:grid-cols-2">
              {[
                { name: "Chess Tempo", url: "https://chesstempo.com", desc: "The ultimate training site for tactics and endgames." },
                { name: "OpeningTree", url: "https://openingtree.com", desc: "Analyze openings using a master database." },
                { name: "Chessable", url: "https://www.chessable.com", desc: "Master openings and endgames through spaced repetition." },
                { name: "Aimchess", url: "https://aimchess.com", desc: "Improve your game with personalized chess insights." }
              ].map((tool, i) => (
                <li key={i} className="flex flex-col sm:flex-row items-center gap-4 p-4 border border-white/5 bg-black/20 group transition-all duration-300">
                  <div className="bg-primary/10 p-3 rounded-none text-primary font-bold text-lg min-w-[50px] text-center border border-primary/20">0{i + 1}</div>
                  <div className="flex-1 text-center sm:text-left">
                     <EditableText 
                        id={`resources.tool.${i + 1}.title`} 
                        className="font-bold text-white block text-lg" 
                        defaultText={tool.name}
                      />
                      <EditableText 
                        id={`resources.tool.${i + 1}.desc`} 
                        className="text-sm text-muted-foreground block mb-2" 
                        defaultText={tool.desc}
                      />
                  </div>
                  <a 
                    href={tool.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center rounded-none bg-primary/10 hover:bg-primary text-primary hover:text-primary-foreground border border-primary/30 h-10 px-6 text-xs font-bold uppercase tracking-widest transition-all duration-300 ease-in-out hover:-translate-y-1 hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/30 cursor-pointer"
                  >
                    Visit <ExternalLink className="ml-2 h-3 w-3" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Downloads Placeholder */}
        <section>
          <h2 className="text-2xl font-display font-bold text-white border-l-4 border-primary pl-4 mb-6 flex items-center gap-3">
            <Download className="text-primary" /> Downloads
          </h2>
          <div className="bg-secondary/10 border border-dashed border-white/10 rounded-lg p-12 text-center">
             <p className="text-muted-foreground mb-4">Space reserved for future downloadable PDFs (Tournament Rules, Score Sheets, etc.)</p>
             <Button disabled variant="secondary">Coming Soon</Button>
          </div>
        </section>
      </div>
    </Layout>
  );
}
