import React, { createContext, useContext, useState, useEffect } from 'react';

// Define types for our content
export type Tournament = {
  id: string;
  name: string;
  location: string;
  dates: string;
  category: string;
  status: 'Ongoing' | 'Upcoming' | 'Completed';
  link: string;
  // International specific
  continent?: string;
  country?: string;
};

export type Result = {
  id: string;
  tournamentName: string;
  winner: string;
  runnerUp?: string;
  topLocal?: string;
  date: string;
  country?: string; // For international/latest
  link?: string;
};

export type StateChampionship = {
  id: string;
  state: string;
  name: string;
  date: string;
  categories: string;
  winner: string;
  link: string;
};

export type ContentState = {
  isEditing: boolean;
  texts: Record<string, string>;
  tournaments: Tournament[];
  results: Result[];
  stateChampionships: StateChampionship[];
  // Actions
  toggleEditMode: () => void;
  updateText: (key: string, value: string) => void;
  addTournament: (t: Omit<Tournament, 'id'>) => void;
  updateTournament: (id: string, t: Partial<Tournament>) => void;
  deleteTournament: (id: string) => void;
  addResult: (r: Omit<Result, 'id'>) => void;
  updateResult: (id: string, r: Partial<Result>) => void;
  deleteResult: (id: string) => void;
  addStateChampionship: (s: Omit<StateChampionship, 'id'>) => void;
  updateStateChampionship: (id: string, s: Partial<StateChampionship>) => void;
  deleteStateChampionship: (id: string) => void;
};

const ContentContext = createContext<ContentState | undefined>(undefined);

const INITIAL_TEXTS = {
  'home.hero.title': 'MY Chess Hub',
  'home.hero.subtitle': 'Tournaments • Results • Learning',
  'home.intro.text': 'MY Chess Hub is a platform dedicated to providing updated chess tournament information, results, and learning resources. The website covers Malaysian and international chess events in one organized place.',
  'home.latest.title': 'Latest Results',
  'tournaments.malaysia.title': 'Malaysia Tournaments',
  'tournaments.international.title': 'International Tournaments',
  'learn.title': 'Learn Chess',
  'learn.moves.title': 'How Pieces Move',
  'learn.moves.text': 'The King moves one square in any direction. The Queen moves any number of squares diagonally, horizontally, or vertically. The Rook moves horizontally or vertically. The Bishop moves diagonally. The Knight moves in an L-shape. The Pawn moves forward, but captures diagonally.',
  'contact.email': 'contact@mychesshub.com',
};

const INITIAL_TOURNAMENTS: Tournament[] = [
  { id: '1', name: 'KL Open 2026', location: 'Kuala Lumpur', dates: 'Feb 20-25, 2026', category: 'Open', status: 'Ongoing', link: '#' },
  { id: '2', name: 'Penang Junior Championship', location: 'Penang', dates: 'Mar 10-12, 2026', category: 'U12, U15', status: 'Upcoming', link: '#' },
  { id: '3', name: 'Asian Continental', location: 'Dubai, UAE', dates: 'Apr 1-10, 2026', category: 'Open', status: 'Upcoming', link: '#', continent: 'Asia', country: 'UAE' },
];

const INITIAL_RESULTS: Result[] = [
  { id: '1', tournamentName: 'National Rapid 2025', winner: 'IM Yeoh Li Tian', date: 'Jan 15, 2026', country: 'Malaysia' },
  { id: '2', tournamentName: 'Tata Steel Chess', winner: 'Gukesh D', date: 'Jan 28, 2026', country: 'Netherlands' },
];

export function ContentProvider({ children }: { children: React.ReactNode }) {
  const [isEditing, setIsEditing] = useState(false);
  
  // Load from local storage or use defaults
  const [texts, setTexts] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('mychesshub_texts');
    return saved ? JSON.parse(saved) : INITIAL_TEXTS;
  });

  const [tournaments, setTournaments] = useState<Tournament[]>(() => {
    const saved = localStorage.getItem('mychesshub_tournaments');
    return saved ? JSON.parse(saved) : INITIAL_TOURNAMENTS;
  });

  const [results, setResults] = useState<Result[]>(() => {
    const saved = localStorage.getItem('mychesshub_results');
    return saved ? JSON.parse(saved) : INITIAL_RESULTS;
  });

  const [stateChampionships, setStateChampionships] = useState<StateChampionship[]>(() => {
    const saved = localStorage.getItem('mychesshub_states');
    return saved ? JSON.parse(saved) : [];
  });

  // Persist to local storage
  useEffect(() => localStorage.setItem('mychesshub_texts', JSON.stringify(texts)), [texts]);
  useEffect(() => localStorage.setItem('mychesshub_tournaments', JSON.stringify(tournaments)), [tournaments]);
  useEffect(() => localStorage.setItem('mychesshub_results', JSON.stringify(results)), [results]);
  useEffect(() => localStorage.setItem('mychesshub_states', JSON.stringify(stateChampionships)), [stateChampionships]);

  const toggleEditMode = () => setIsEditing(prev => !prev);

  const updateText = (key: string, value: string) => {
    setTexts(prev => ({ ...prev, [key]: value }));
  };

  const addTournament = (t: Omit<Tournament, 'id'>) => {
    const newTournament = { ...t, id: Math.random().toString(36).substr(2, 9) };
    setTournaments(prev => [...prev, newTournament]);
  };

  const updateTournament = (id: string, t: Partial<Tournament>) => {
    setTournaments(prev => prev.map(item => item.id === id ? { ...item, ...t } : item));
  };

  const deleteTournament = (id: string) => {
    setTournaments(prev => prev.filter(item => item.id !== id));
  };

  const addResult = (r: Omit<Result, 'id'>) => {
    const newResult = { ...r, id: Math.random().toString(36).substr(2, 9) };
    setResults(prev => [newResult, ...prev]); // Add to top
  };

  const updateResult = (id: string, r: Partial<Result>) => {
    setResults(prev => prev.map(item => item.id === id ? { ...item, ...r } : item));
  };

  const deleteResult = (id: string) => {
    setResults(prev => prev.filter(item => item.id !== id));
  };

  const addStateChampionship = (s: Omit<StateChampionship, 'id'>) => {
    const newItem = { ...s, id: Math.random().toString(36).substr(2, 9) };
    setStateChampionships(prev => [...prev, newItem]);
  };

  const updateStateChampionship = (id: string, s: Partial<StateChampionship>) => {
    setStateChampionships(prev => prev.map(item => item.id === id ? { ...item, ...s } : item));
  };

  const deleteStateChampionship = (id: string) => {
    setStateChampionships(prev => prev.filter(item => item.id !== id));
  };

  return (
    <ContentContext.Provider value={{
      isEditing,
      texts,
      tournaments,
      results,
      stateChampionships,
      toggleEditMode,
      updateText,
      addTournament,
      updateTournament,
      deleteTournament,
      addResult,
      updateResult,
      deleteResult,
      addStateChampionship,
      updateStateChampionship,
      deleteStateChampionship,
    }}>
      {children}
    </ContentContext.Provider>
  );
}

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};
