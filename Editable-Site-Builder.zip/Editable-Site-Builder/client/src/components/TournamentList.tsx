import { useState } from "react";
import { useContent, Tournament } from "@/lib/ContentContext";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Calendar, ExternalLink, Trophy, Trash2, Edit2, Plus, ArrowRightCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function TournamentList({ 
  filter, 
  title 
}: { 
  filter: (t: Tournament) => boolean, 
  title: string 
}) {
  const { isEditing, tournaments, addTournament, updateTournament, deleteTournament, addResult } = useContent();
  const { toast } = useToast();
  
  // Form State
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Tournament>>({
    name: "", location: "", dates: "", category: "", status: "Upcoming", link: "", country: "Malaysia"
  });

  const filteredTournaments = tournaments.filter(filter);

  const handleOpenAdd = () => {
    setEditingId(null);
    setFormData({ name: "", location: "", dates: "", category: "Open", status: "Upcoming", link: "", country: "Malaysia" });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (t: Tournament) => {
    setEditingId(t.id);
    setFormData(t);
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (editingId) {
      updateTournament(editingId, formData);
    } else {
      addTournament(formData as Omit<Tournament, 'id'>);
    }
    setIsDialogOpen(false);
  };

  const handleMoveToResults = (t: Tournament) => {
    // 1. Add to results
    addResult({
        tournamentName: t.name,
        winner: "TBD", // Placeholder for them to edit
        date: new Date().toLocaleDateString(),
        country: t.country || "Malaysia"
    });
    
    // 2. Mark as completed
    updateTournament(t.id, { status: "Completed" });

    toast({
        title: "Tournament Moved",
        description: `${t.name} marked as completed and added to Results table.`
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-display font-bold text-white border-l-4 border-primary pl-4">{title}</h2>
        {isEditing && (
          <Button onClick={handleOpenAdd} size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="mr-2 h-4 w-4" /> Add Tournament
          </Button>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredTournaments.length === 0 ? (
          <div className="col-span-full py-16 text-center text-muted-foreground bg-secondary/10 border border-dashed border-white/5">
            No active tournaments found. {isEditing && "Add one above!"}
          </div>
        ) : (
          filteredTournaments.map((t) => (
            <Card key={t.id} className="group relative rounded-none bg-secondary/30 border-white/5 hover:border-primary transition-all duration-300">
              {isEditing && (
                <div className="absolute top-2 right-2 z-10 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-black/80 p-1 backdrop-blur-sm">
                  {t.status !== 'Completed' && (
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-green-400 hover:text-green-300" title="Move to Results" onClick={() => handleMoveToResults(t)}>
                        <ArrowRightCircle size={14} />
                      </Button>
                  )}
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-white hover:text-primary" onClick={() => handleOpenEdit(t)}>
                    <Edit2 size={14} />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:text-red-400" onClick={() => deleteTournament(t.id)}>
                    <Trash2 size={14} />
                  </Button>
                </div>
              )}
              
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-4">
                  <Badge variant={t.status === 'Ongoing' ? "default" : "secondary"} className={cn("rounded-none px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider", t.status === 'Ongoing' ? "bg-primary text-primary-foreground" : "bg-white/10 text-white")}>
                    {t.status}
                  </Badge>
                  {t.country && <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t.country}</span>}
                </div>
                <CardTitle className="text-xl font-display font-bold leading-tight group-hover:text-primary transition-colors uppercase">
                  {t.name}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4 text-sm text-muted-foreground border-y border-white/5 py-4 my-2">
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-primary/60" />
                  <span className="font-medium text-white/80">{t.location}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-primary/60" />
                  <span className="font-medium text-white/80">{t.dates}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Trophy className="h-4 w-4 text-primary/60" />
                  <span className="font-medium text-white/80">{t.category}</span>
                </div>
              </CardContent>
              
              <CardFooter className="pt-2">
                <Button asChild className="w-full rounded-none bg-black/40 hover:bg-primary hover:text-primary-foreground text-white border-none" variant="outline">
                  <a href={t.link || "#"} target="_blank" rel="noopener noreferrer">
                    OFFICIAL INFO <ExternalLink className="ml-2 h-3 w-3" />
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-card border-white/10 text-white sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Tournament" : "Add Tournament"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Tournament Name</Label>
              <Input id="name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" value={formData.location} onChange={(e) => setFormData({...formData, location: e.target.value})} className="bg-secondary/50 border-white/10" />
              </div>
               <div className="grid gap-2">
                <Label htmlFor="country">Country</Label>
                <Input id="country" value={formData.country} onChange={(e) => setFormData({...formData, country: e.target.value})} className="bg-secondary/50 border-white/10" />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="dates">Dates</Label>
              <Input id="dates" value={formData.dates} onChange={(e) => setFormData({...formData, dates: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Input id="category" value={formData.category} onChange={(e) => setFormData({...formData, category: e.target.value})} className="bg-secondary/50 border-white/10" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(val: any) => setFormData({...formData, status: val})}>
                  <SelectTrigger className="bg-secondary/50 border-white/10">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-white/10">
                    <SelectItem value="Upcoming">Upcoming</SelectItem>
                    <SelectItem value="Ongoing">Ongoing</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="link">Official Link</Label>
              <Input id="link" value={formData.link} onChange={(e) => setFormData({...formData, link: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSave} className="bg-primary text-primary-foreground hover:bg-primary/90">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
