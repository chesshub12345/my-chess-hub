import { Link, useLocation } from "wouter";
import { Navbar } from "./Navbar";
import { useContent } from "@/lib/ContentContext";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const { isEditing } = useContent();

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans selection:bg-primary/30 selection:text-white">
      <Navbar />
      
      {isEditing && (
        <div className="bg-primary/20 border-b border-primary/30 text-primary-foreground px-4 py-2 text-center text-sm font-medium animate-pulse">
          EDIT MODE ACTIVE - You can click on text and lists to modify content
        </div>
      )}
      
      <main className="flex-1 w-full">
        {children}
      </main>
      
      <footer className="border-t border-white/10 bg-black py-12">
        <div className="container grid gap-8 md:grid-cols-4">
          <div className="md:col-span-2">
             <h3 className="text-xl font-display font-bold text-white mb-4">
                <span className="text-primary">MY</span> CHESS HUB
             </h3>
             <p className="text-muted-foreground max-w-sm">
               The ultimate resource for chess players in Malaysia and beyond. Updated weekly with the latest tournaments and results.
             </p>
          </div>
          <div>
            <h4 className="font-bold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/tournaments">Tournaments</Link></li>
              <li><Link href="/learn">Learn Chess</Link></li>
              <li><Link href="/resources">Resources</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-white mb-4">Contact</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>info@mychesshub.com</li>
              <li>Kuala Lumpur, Malaysia</li>
            </ul>
          </div>
        </div>
        <div className="container mt-12 pt-8 border-t border-white/5 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} MY Chess Hub. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
