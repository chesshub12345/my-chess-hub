import { Link, useLocation } from "wouter";
import { useContent } from "@/lib/ContentContext";
import { cn } from "@/lib/utils";
import logo from "@/assets/logo.png";
import { Edit3, Eye, Menu, X, Check, Plus } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

export function Navbar() {
  const { isEditing, toggleEditMode } = useContent();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const links = [
    { href: "/", label: "Home" },
    { href: "/tournaments", label: "Tournaments" },
    { href: "/learn", label: "Learn Chess" },
    { href: "/resources", label: "Resources" },
    { href: "/contact", label: "Contact" },
  ];

  const [password, setPassword] = useState("");
  const [showLogin, setShowLogin] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "232323") {
      toggleEditMode();
      setShowLogin(false);
      setPassword("");
    } else {
      alert("Incorrect admin password");
    }
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/">
            <a className="flex items-center gap-2 font-display text-xl font-bold tracking-wider text-white hover:opacity-90 transition-opacity">
              <img src={logo} alt="MY Chess Hub" className="h-8 w-8 object-contain" />
              <span className="text-primary">MY</span> CHESS HUB
            </a>
          </Link>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <a
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location === link.href ? "text-primary" : "text-muted-foreground"
                )}
              >
                {link.label}
              </a>
            </Link>
          ))}
          
          {isEditing ? (
            <Button
              onClick={toggleEditMode}
              variant="default"
              size="sm"
              className="ml-4 gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Eye size={16} />
              View Mode
            </Button>
          ) : null}

          {isEditing && (
            <Link href="/tournaments/create">
              <Button
                variant="outline"
                size="sm"
                className="ml-2 gap-2 border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
              >
                <Plus size={16} />
                Create Event
              </Button>
            </Link>
          )}

          {!isEditing && (
            <div className="flex items-center gap-2 ml-4">
              {showLogin ? (
                <form onSubmit={handleLogin} className="flex items-center gap-2 animate-in fade-in slide-in-from-right-2">
                  <input
                    type="password"
                    placeholder="Admin password..."
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-8 w-32 rounded border border-white/10 bg-white/5 px-2 text-xs text-white focus:border-primary focus:outline-none"
                    autoFocus
                  />
                  <Button type="submit" size="sm" className="h-8 bg-primary text-primary-foreground">
                    <Check size={14} />
                  </Button>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 text-white"
                    onClick={() => setShowLogin(false)}
                  >
                    <X size={14} />
                  </Button>
                </form>
              ) : (
                <Button
                  onClick={() => setShowLogin(true)}
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground/30 hover:text-primary transition-colors"
                >
                  <Edit3 size={16} />
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <div className="flex md:hidden items-center gap-2">
            {!isEditing && !showLogin && (
              <Button
                onClick={() => setShowLogin(true)}
                variant="ghost"
                size="icon"
                className="text-muted-foreground/30"
              >
                <Edit3 size={18} />
              </Button>
            )}
            {isEditing && (
              <Button
                onClick={toggleEditMode}
                variant="ghost"
                size="icon"
                className="text-primary bg-primary/20"
              >
                <Eye size={18} />
              </Button>
            )}
            <Button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            variant="ghost"
            size="icon"
            className="text-white"
            >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-background p-4 animate-in slide-in-from-top-5">
          <div className="flex flex-col gap-4">
            {links.map((link) => (
              <Link key={link.href} href={link.href}>
                <a
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "text-base font-medium transition-colors hover:text-primary px-2 py-1 rounded-md hover:bg-white/5",
                    location === link.href ? "text-primary bg-white/5" : "text-muted-foreground"
                  )}
                >
                  {link.label}
                </a>
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
