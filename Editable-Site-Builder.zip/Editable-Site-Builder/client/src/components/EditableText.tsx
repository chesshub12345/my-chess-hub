import React, { useState, useEffect, useRef } from 'react';
import { useContent } from '@/lib/ContentContext';
import { cn } from '@/lib/utils';
import { Edit2, Check, X } from 'lucide-react';

interface EditableTextProps {
  id: string;
  defaultText?: string;
  className?: string;
  multiline?: boolean;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'p' | 'span' | 'div';
}

export function EditableText({ id, defaultText = '', className, multiline = false, as: Component = 'span' }: EditableTextProps) {
  const { isEditing, texts, updateText } = useContent();
  const [value, setValue] = useState(texts[id] || defaultText);
  const [isFocused, setIsFocused] = useState(false);

  // Sync with context on mount/update
  useEffect(() => {
    if (!texts[id] && defaultText) {
      updateText(id, defaultText);
    }
  }, [id, defaultText, texts, updateText]);

  useEffect(() => {
    if (texts[id]) {
      setValue(texts[id]);
    }
  }, [texts, id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setValue(e.target.value);
    updateText(id, e.target.value);
  };

  if (isEditing) {
    return (
      <div className="relative group inline-block w-full">
        {multiline ? (
          <textarea
            value={value}
            onChange={handleChange}
            className={cn(
              "w-full bg-secondary/30 border border-primary/50 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary min-h-[100px]",
              className
            )}
            placeholder="Click to edit..."
          />
        ) : (
          <input
            type="text"
            value={value}
            onChange={handleChange}
            className={cn(
              "w-full bg-secondary/30 border border-primary/50 px-1 rounded focus:outline-none focus:ring-2 focus:ring-primary",
              className
            )}
            placeholder="Click to edit..."
          />
        )}
        <div className="absolute -top-3 -right-3 bg-primary text-primary-foreground p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <Edit2 size={12} />
        </div>
      </div>
    );
  }

  return (
    <Component className={className}>
      {value || <span className="text-muted-foreground/50 italic">Empty section</span>}
    </Component>
  );
}
