import React, { useState } from "react";
import { useContent, Result } from "@/lib/ContentContext";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Edit2, Plus, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

interface ResultsTableProps {
  limit?: number;
  title?: string;
  showCountry?: boolean;
}

export function ResultsTable({ limit, title, showCountry = true }: ResultsTableProps) {
  const { isEditing, results, addResult, updateResult, deleteResult } = useContent();
  const displayResults = limit ? results.slice(0, limit) : results;
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Result>>({
    tournamentName: "", winner: "", date: "", country: "Malaysia"
  });

  const handleOpenAdd = () => {
    setEditingId(null);
    setFormData({ tournamentName: "", winner: "", date: "", country: "Malaysia" });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (r: Result) => {
    setEditingId(r.id);
    setFormData(r);
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (editingId) {
      updateResult(editingId, formData);
    } else {
      addResult(formData as Omit<Result, 'id'>);
    }
    setIsDialogOpen(false);
  };

  return (
    <div className="w-full space-y-4">
      <div className="flex items-center justify-between mb-4">
         {title && <h3 className="text-xl font-display font-bold text-white flex items-center gap-2">
           <Trophy className="text-primary h-5 w-5" />
           {title}
         </h3>}
         {isEditing && (
          <Button onClick={handleOpenAdd} size="sm" variant="outline" className="text-primary border-primary/50 hover:bg-primary/10">
            <Plus className="mr-2 h-4 w-4" /> Add Result
          </Button>
        )}
      </div>

      <div className="rounded-none border border-white/5 overflow-hidden bg-secondary/30">
        <Table>
          <TableHeader className="bg-black/40">
            <TableRow className="border-white/5 hover:bg-transparent">
              <TableHead className="text-muted-foreground uppercase text-xs font-bold tracking-widest w-[30%]">Tournament</TableHead>
              {showCountry && <TableHead className="text-muted-foreground uppercase text-xs font-bold tracking-widest">Region</TableHead>}
              <TableHead className="text-muted-foreground uppercase text-xs font-bold tracking-widest w-[30%]">Winner</TableHead>
              <TableHead className="text-muted-foreground uppercase text-xs font-bold tracking-widest text-right">Date</TableHead>
              {isEditing && <TableHead className="w-[100px] text-center">Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayResults.length === 0 ? (
               <TableRow>
                 <TableCell colSpan={isEditing ? 5 : 4} className="h-24 text-center text-muted-foreground italic">
                   No results recorded yet.
                 </TableCell>
               </TableRow>
            ) : (
              displayResults.map((r) => (
                <TableRow key={r.id} className="border-white/5 hover:bg-white/5 transition-colors">
                  <TableCell className="font-medium text-white">{r.tournamentName}</TableCell>
                  {showCountry && <TableCell className="text-muted-foreground text-sm">{r.country || "Malaysia"}</TableCell>}
                  <TableCell className="text-primary font-bold">{r.winner}</TableCell>
                  <TableCell className="text-right text-muted-foreground text-sm">{r.date}</TableCell>
                  {isEditing && (
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-2">
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-white" onClick={() => handleOpenEdit(r)}>
                          <Edit2 size={12} />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500/70 hover:text-red-500 hover:bg-red-500/10" onClick={() => deleteResult(r.id)}>
                          <Trash2 size={12} />
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

       {/* Edit Dialog */}
       <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-card border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Result" : "Add Result"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="tournamentName">Tournament Name</Label>
              <Input id="tournamentName" value={formData.tournamentName} onChange={(e) => setFormData({...formData, tournamentName: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="country">Country / State</Label>
              <Input id="country" value={formData.country} onChange={(e) => setFormData({...formData, country: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="winner">Winner</Label>
              <Input id="winner" value={formData.winner} onChange={(e) => setFormData({...formData, winner: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="date">Date</Label>
              <Input id="date" value={formData.date} onChange={(e) => setFormData({...formData, date: e.target.value})} className="bg-secondary/50 border-white/10" />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSave} className="bg-primary text-primary-foreground hover:bg-primary/90">Save Result</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
